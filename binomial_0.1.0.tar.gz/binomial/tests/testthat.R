library(testthat)
library(binomial)

test_check("binomial")
