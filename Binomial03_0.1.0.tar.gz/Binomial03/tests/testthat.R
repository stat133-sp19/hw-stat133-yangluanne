library(testthat)
library(Binomial03)

test_check("Binomial03")
